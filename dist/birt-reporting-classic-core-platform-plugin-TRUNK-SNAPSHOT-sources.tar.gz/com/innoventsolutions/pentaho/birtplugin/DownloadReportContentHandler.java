package com.innoventsolutions.pentaho.birtplugin;

public class DownloadReportContentHandler {
}
