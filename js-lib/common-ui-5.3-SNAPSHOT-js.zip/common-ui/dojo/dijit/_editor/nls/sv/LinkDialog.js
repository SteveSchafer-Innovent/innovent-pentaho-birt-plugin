define(
({
	createLinkTitle: "Länkegenskaper",
	insertImageTitle: "Bildegenskaper",
	url: "URL-adress:",
	text: "Beskrivning:",
	target: "Mål:",
	set: "Använd",
	currentWindow: "Aktuellt fönster",
	parentWindow: "Överordnat fönster",
	topWindow: "Översta fönstret",
	newWindow: "Nytt fönster"
})
);
