define([],function(){var e={getEmailConfig:function(){return CONTEXT_PATH+"api/emailconfig"
},getScheduledJob:function(){return CONTEXT_PATH+"api/scheduler/job"}};return e});
