define([],function(){var r={getCggDrawUrl:function(){return CONTEXT_PATH+"plugin/cgg/api/services/draw"
}};return r});