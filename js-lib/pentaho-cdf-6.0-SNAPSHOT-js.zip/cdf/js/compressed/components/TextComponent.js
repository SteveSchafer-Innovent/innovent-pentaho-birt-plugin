define(["./BaseComponent"],function(e){var n=e.extend({update:function(){this.placeholder().html(this.expression())
}});return n});