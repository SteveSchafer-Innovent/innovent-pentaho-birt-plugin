define(["./Dashboard.ext"],function(e){var t={getStorage:function(t){return e.getCdfBase()+"/storage/"+t
}};return t});