define(["./Dashboard.ext"],function(t){var e={getContext:function(){return t.getCdfBase()+"/context/get"
}};return e});