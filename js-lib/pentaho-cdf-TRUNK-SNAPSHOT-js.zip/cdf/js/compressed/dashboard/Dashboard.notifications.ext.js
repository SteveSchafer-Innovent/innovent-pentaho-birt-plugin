define(["./Dashboard.ext"],function(n){var e={getPing:function(){return n.getCdfBase()+"/ping"
}};return e});