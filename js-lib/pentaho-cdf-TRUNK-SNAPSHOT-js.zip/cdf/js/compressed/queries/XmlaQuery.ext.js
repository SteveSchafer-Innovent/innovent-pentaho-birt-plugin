define([],function(){var n={getXmla:function(){return CONTEXT_PATH+"/Xmla"}};return n
});