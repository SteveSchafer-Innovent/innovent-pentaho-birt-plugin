define(["./SelectBaseComponent"],function(e){var t=e.extend({defaultIfEmpty:!0,getValue:function(){return this.placeholder("select").val()
}});return t});