define(["../dashboard/Dashboard.ext"],function(r){var e={getCccScriptPath:function(e){return r.getFilePathFromUrl().replace(/[^\/]+$/,"")+e+".js"
}};return e});