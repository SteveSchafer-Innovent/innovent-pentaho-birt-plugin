define(["amd!cdf/lib/backbone","./baseevents"],function(e,n){var a=n.convertClass(e.Model);
return a});