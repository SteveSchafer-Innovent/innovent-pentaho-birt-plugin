define(["./BaseFilter","./templates","./defaults","./Logger"],function(e){return e
});