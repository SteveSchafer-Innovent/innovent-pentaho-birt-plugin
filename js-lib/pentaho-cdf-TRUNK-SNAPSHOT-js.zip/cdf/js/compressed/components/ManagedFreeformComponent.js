define(["./BaseComponent"],function(n){var t=n.extend({update:function(){this.customfunction(this.parameters||[])
}});return t});