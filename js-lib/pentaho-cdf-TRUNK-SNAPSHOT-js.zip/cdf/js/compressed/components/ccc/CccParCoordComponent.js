define(["./BaseCccComponent","../lib/CCC/pvc"],function(e,n){var c=e.extend({cccType:n.ParallelCoordinates});
return c});