define(["./BaseCccComponent","../lib/CCC/pvc"],function(e,c){var n=e.extend({cccType:c.BarChart});
return n});