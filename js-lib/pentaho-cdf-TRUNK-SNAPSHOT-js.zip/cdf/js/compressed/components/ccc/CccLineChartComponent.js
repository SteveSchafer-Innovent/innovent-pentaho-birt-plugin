define(["./BaseCccComponent","../lib/CCC/pvc"],function(e,n){var c=e.extend({cccType:n.LineChart});
return c});